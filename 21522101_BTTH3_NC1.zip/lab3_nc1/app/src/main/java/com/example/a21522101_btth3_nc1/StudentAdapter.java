package com.example.a21522101_btth3_nc1;


import android.widget.ArrayAdapter;
import android.app.Activity;
import java.util.List;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.*;

public class StudentAdapter extends ArrayAdapter<Student> {
    private Activity context;
    public StudentAdapter(Activity context, int layoutID, List<Student> objects) {
        super(context, layoutID, objects);
        this.context = context;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_student, null, false);
        }

        Student student = getItem(position);

        TextView tvStudent = (TextView) convertView.findViewById(R.id.tv_student);
        tvStudent.setText(student.getMSSV() + " - " + student.getHoTen() + " - " + student.getLop());

        return convertView;
    }
}